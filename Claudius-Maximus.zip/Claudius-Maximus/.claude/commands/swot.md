---
description: Run a SWOT analysis
argument-hint: "[business/idea/self]"
---

Run a SWOT analysis on: $ARGUMENTS

Strengths, weaknesses, opportunities, threats, each with specific points, not generic ones. End with the 2 moves the SWOT actually points to.
