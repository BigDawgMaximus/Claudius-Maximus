---
description: Brainstorm revenue ideas
argument-hint: "[product or audience]"
---

Give me revenue ideas for: $ARGUMENTS

List 8 ways to monetize across one-time, recurring, and high-ticket. For each: who pays, for what, and rough price. Rank by ease vs upside.
