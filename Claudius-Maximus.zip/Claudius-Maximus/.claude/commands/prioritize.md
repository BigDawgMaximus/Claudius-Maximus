---
description: Decide what to do first
argument-hint: "[task list]"
---

Help me prioritize: $ARGUMENTS

Rank by impact and urgency. Name the single most important task, what to do next, and what to delete or defer. Be decisive.
