---
description: Give real examples
argument-hint: "[concept]"
---

Give me real, concrete examples of: $ARGUMENTS

3 to 5 examples from the real world, ordered simple to advanced. For each, show how it maps back to the concept. Make the abstract feel obvious.
