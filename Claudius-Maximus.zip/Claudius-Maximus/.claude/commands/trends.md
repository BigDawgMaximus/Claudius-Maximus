---
description: Spot patterns and trends
argument-hint: "[data or topic]"
---

Identify the patterns and trends in: $ARGUMENTS

Separate signal from noise, name what's actually changing vs hype, and say what it likely means. Note the assumptions your read depends on.
