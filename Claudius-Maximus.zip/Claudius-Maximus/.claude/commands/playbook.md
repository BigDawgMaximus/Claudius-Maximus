---
description: Build a repeatable system
argument-hint: "[recurring task]"
---

Turn this into a repeatable playbook: $ARGUMENTS
A step-by-step system I can run every time, with triggers, the process, and the standard for good. Make it copy-paste reusable.
