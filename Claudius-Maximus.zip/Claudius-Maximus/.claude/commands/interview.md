---
description: Prep interview questions and answers
argument-hint: "[role]"
---

Prep me for interviews for: $ARGUMENTS

Give the 10 most likely questions, what each is really testing, and a strong sample answer using STAR for the behavioral ones.
