---
description: Write cold outreach
argument-hint: "[who + goal]"
---

Write a cold outreach message for: $ARGUMENTS

Short, personalized, about them not me. Open with a relevant reason for reaching out, give one clear value, and end with a low-friction ask. Give 2 variants.
