---
description: Write social captions
argument-hint: "[topic or image]"
---

Write 5 caption options for: $ARGUMENTS

Vary length and tone (one-liner, story, listicle, question-led, bold claim). Each should stand on its own and end with a reason to engage.
