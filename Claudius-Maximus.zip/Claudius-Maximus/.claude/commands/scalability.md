---
description: Plan a scaling approach
argument-hint: "[system + bottleneck]"
---

Give me a scaling approach for: $ARGUMENTS

Identify the bottleneck, then cover caching, scaling reads/writes, queues, and statelessness as relevant. Order changes by impact vs effort.
