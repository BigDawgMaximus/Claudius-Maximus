---
description: Give only the final answer
argument-hint: "[task]"
---

Do this and return ONLY the final answer: $ARGUMENTS
No preamble, no explanation, no "here is", no closing remarks. Just the deliverable.
