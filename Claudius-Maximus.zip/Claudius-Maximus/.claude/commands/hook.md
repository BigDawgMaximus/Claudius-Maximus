---
description: Generate 10 strong opening lines
argument-hint: "[topic]"
---

Give me 10 different opening hooks for: $ARGUMENTS

Mix the styles: bold claim, contrarian take, specific number, question, "most people get this wrong", and a short story open. Rank them strongest first.
