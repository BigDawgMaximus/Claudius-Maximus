---
description: Refactor for clean code
argument-hint: "[code]"
---

Refactor this code for readability and maintainability: $ARGUMENTS

Keep behavior identical. Improve naming, structure, and duplication. Show the refactored version and a short note on what changed and why.
