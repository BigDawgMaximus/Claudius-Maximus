---
description: Increase engagement
argument-hint: "[account or post type]"
---

Give me ways to increase engagement for: $ARGUMENTS

Be tactical: hook patterns, formats, comment strategy, and posting habits that actually move replies and saves. Prioritize the 3 with the highest payoff.
