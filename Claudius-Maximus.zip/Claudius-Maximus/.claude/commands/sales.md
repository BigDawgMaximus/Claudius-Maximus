---
description: Write a sales pitch
argument-hint: "[product + audience]"
---

Write a sales pitch for: $ARGUMENTS

Use problem, stakes, solution, proof, offer, and a clear next step. Lead with their pain, not my features. Keep it tight and confident.
