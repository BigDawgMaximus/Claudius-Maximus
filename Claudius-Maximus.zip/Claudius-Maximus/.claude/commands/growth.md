---
description: Build a growth strategy
argument-hint: "[platform + goal]"
---

Build a growth strategy for: $ARGUMENTS

Cover content, consistency, distribution, and one growth loop. Give me a simple weekly routine I can actually keep. Name the single highest-leverage move first.
