---
description: Find and cite sources
argument-hint: "[topic/claim]"
---

Find credible sources for: $ARGUMENTS

Prioritize primary and authoritative sources. For each, note what it supports and how strong it is. Skip low-quality sources and say if the evidence is thin.
