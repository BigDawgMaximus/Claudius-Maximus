---
description: Find niche clarity
argument-hint: "[what I do / interests]"
---

Help me get niche clarity from: $ARGUMENTS

Propose 3 specific niche angles (audience + problem + outcome). For each, give the ideal follower, the core message, and why it could work. Recommend one.
