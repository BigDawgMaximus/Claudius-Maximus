---
description: Compare options objectively
argument-hint: "[options]"
---

Compare these objectively: $ARGUMENTS

Use a criteria table (the factors that actually matter), call out the real tradeoffs, and give a recommendation with the conditions under which a different choice wins.
