---
description: Weigh the tradeoffs
argument-hint: "[decision]"
---

Lay out the pros and cons of: $ARGUMENTS

Be balanced and specific. Weight each point by how much it actually matters, not just list them. End with the deciding factor.
