---
description: Answer common HR-round questions
argument-hint: "[role or situation]"
---

Help me answer HR-round questions for: $ARGUMENTS

Cover "tell me about yourself", strengths/weaknesses, why this company, salary expectations, and why you left. Give honest, non-cringe sample answers.
