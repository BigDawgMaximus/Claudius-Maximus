---
description: Design a validation test
argument-hint: "[idea]"
---

Design a cheap validation test for: $ARGUMENTS

Identify the riskiest assumption, the fastest test, the signal that means "go", and the signal that means "stop". Keep it doable in under 2 weeks.
