---
description: Summarize a long document
argument-hint: "[document text]"
---

Summarize this document: $ARGUMENTS

Give the main argument in 2 lines, the key points, any important data, and the decisions or actions it implies. Note anything that's unclear or missing.
