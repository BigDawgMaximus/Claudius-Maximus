---
description: Generate tests
argument-hint: "[function or feature]"
---

Generate test cases for: $ARGUMENTS

Cover happy path, edge cases, and failure cases. Write them in the relevant framework. Note any case that's easy to forget.
