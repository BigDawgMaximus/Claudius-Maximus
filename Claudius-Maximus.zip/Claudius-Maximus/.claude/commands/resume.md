---
description: Improve a resume
argument-hint: "[resume text]"
---

Improve this resume: $ARGUMENTS

Rewrite weak bullets into result-driven ones (action + metric + impact). Flag anything vague or filler. Tailor toward the role if I named one. Keep it honest.
