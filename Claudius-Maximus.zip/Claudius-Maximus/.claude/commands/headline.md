---
description: Write LinkedIn/bio headline options
argument-hint: "[role + focus]"
---

Write 10 headline options for: $ARGUMENTS

Lead with who I help and the outcome, not just my job title. Keep each scannable. Mark the strongest one.
