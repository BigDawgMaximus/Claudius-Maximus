---
description: Remove distractions
argument-hint: "[situation]"
---

Help me remove distractions for: $ARGUMENTS

Identify the likely triggers, give environment and app changes, and a simple focus routine. Keep it to a few changes I'll actually stick to.
