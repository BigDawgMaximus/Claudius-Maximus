---
description: Answer in bullet format
argument-hint: "[topic]"
---

Answer this in clean bullet points: $ARGUMENTS
Short, parallel bullets, grouped under headers if it helps. No long paragraphs.
