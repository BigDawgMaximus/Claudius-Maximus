---
description: Build a job-search strategy
argument-hint: "[role + situation]"
---

Build a job-search strategy for: $ARGUMENTS

Cover targeting, applications, referrals, outreach, and follow-up. Focus on the channels that actually land interviews, not just volume. Give a weekly plan.
