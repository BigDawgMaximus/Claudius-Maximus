---
description: Build a habit
argument-hint: "[goal]"
---

Help me build the habit of: $ARGUMENTS

Make it tiny to start, attach it to an existing cue, and design the environment to make it easy. Add a simple way to track it and recover after a miss.
