---
description: Find automation opportunities
argument-hint: "[workflow]"
---

Find automation opportunities in: $ARGUMENTS

List the repetitive steps, what could be automated, and the tool or approach for each. Rank by time saved vs effort to set up.
