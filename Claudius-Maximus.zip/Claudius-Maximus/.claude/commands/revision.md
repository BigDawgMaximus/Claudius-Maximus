---
description: Quick revision notes
argument-hint: "[topic]"
---

Make quick revision notes for: $ARGUMENTS

Tight, scannable, exam-style. Key definitions, formulas, and the points most likely to be tested. The kind of thing I'd read 30 minutes before a test.
