---
description: Answer with no examples
argument-hint: "[topic]"
---

Answer this with the principle/explanation only, no examples and no analogies: $ARGUMENTS
Just the direct concepts and reasoning.
