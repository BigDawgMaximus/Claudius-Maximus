---
description: Write a referral request
argument-hint: "[role + contact]"
---

Write a referral request message for: $ARGUMENTS

Make it easy to say yes: remind them how we know each other, be specific about the role, and attach what they need. Keep it short. Give a warm and a cold version.
