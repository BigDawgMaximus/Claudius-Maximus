---
description: Rewrite in a credible expert tone
argument-hint: "[draft or topic]"
---

Rewrite this so it sounds like a credible expert, not a hype account: $ARGUMENTS

Be specific, show reasoning, drop the buzzwords, and make confident claims you can back up. Add one nuance or caveat that signals real depth.
