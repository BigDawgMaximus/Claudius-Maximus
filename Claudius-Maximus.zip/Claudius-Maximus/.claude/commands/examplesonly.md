---
description: Answer with examples only
argument-hint: "[topic]"
---

Answer this with examples only, no explanation: $ARGUMENTS
Just concrete, varied examples that make the point self-evident.
