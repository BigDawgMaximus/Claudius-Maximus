---
description: Run a security check
argument-hint: "[code or system]"
---

Do a security review of: $ARGUMENTS

Check for the common issues (injection, auth, secrets, access control, input validation, dependencies). List findings by severity with the concrete fix for each.
