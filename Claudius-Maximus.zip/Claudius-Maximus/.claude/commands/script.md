---
description: Write a tight video or reel script
argument-hint: "[topic]"
---

Write a short-form video script about: $ARGUMENTS

- First 3 seconds are a visual + spoken hook that promises a payoff.
- Spoken lines only, conversational, no stage directions unless useful.
- Build to one clear point. End on a strong line. Target 30 to 60 seconds.
