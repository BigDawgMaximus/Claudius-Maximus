---
description: Build a content calendar
argument-hint: "[niche + goal]"
---

Build a 4-week content calendar for: $ARGUMENTS

Mix content pillars (teach, story, opinion, proof, offer). Give a post idea + hook for each slot, 3 posts a week. Note which pillar each one serves.
