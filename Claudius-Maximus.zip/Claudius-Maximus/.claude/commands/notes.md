---
description: Make structured notes
argument-hint: "[topic or text]"
---

Make structured notes on: $ARGUMENTS

Use clear headings and short bullets. Bold the key terms. Add a "why it matters" line per section. Built for reviewing later, not reading like prose.
