---
description: Build a go-to-market plan
argument-hint: "[product]"
---

Build a go-to-market plan for: $ARGUMENTS

Cover ICP, positioning, the first channel, the offer, and the first 90 days. Keep it focused on one wedge, not everything at once.
