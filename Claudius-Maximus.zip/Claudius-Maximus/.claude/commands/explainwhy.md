---
description: Explain the reasoning
argument-hint: "[claim or topic]"
---

Explain the WHY behind: $ARGUMENTS

Don't just state the fact. Walk through the cause, the mechanism, and the reasoning so it actually sticks. Use a simple analogy if it helps.
