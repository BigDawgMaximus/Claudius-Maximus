---
description: Rewrite in a casual tone
argument-hint: "[text]"
---

Rewrite this in a casual, friendly tone: $ARGUMENTS
Like talking to a smart friend. Contractions, short sentences, warm, still clear.
