---
description: Limit the word count
argument-hint: "[word limit + topic]"
---

Answer within the word limit I give here: $ARGUMENTS
Treat the number as a hard cap. Make every word earn its place. If I didn't give a number, use 100 words.
