---
description: Give clear numbered steps
argument-hint: "[task]"
---

Answer this as clear, numbered steps: $ARGUMENTS
Each step is one concrete action. Order matters. Flag anything easy to get wrong.
