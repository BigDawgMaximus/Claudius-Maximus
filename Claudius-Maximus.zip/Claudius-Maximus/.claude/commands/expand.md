---
description: Give a detailed explanation
argument-hint: "[task]"
---

Answer this in depth: $ARGUMENTS
Cover the what, why, how, and the nuances. Use structure so it stays readable. Thorough, not padded.
