---
description: Decide what to delegate
argument-hint: "[role/tasks]"
---

Help me decide what to delegate from: $ARGUMENTS

Sort tasks into do, delegate, automate, delete. For the delegate pile, note who could own it and what a good handoff looks like.
