---
description: Review and improve a LinkedIn profile
argument-hint: "[profile text or url]"
---

Review this LinkedIn profile and improve it: $ARGUMENTS

Audit the headline, about section, and experience for clarity and positioning. Point out what's weak, then rewrite the headline and the first 3 lines of the about section.
