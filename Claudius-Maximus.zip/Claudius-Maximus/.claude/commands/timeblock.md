---
description: Time-block the day
argument-hint: "[tasks + constraints]"
---

Time-block my day from: $ARGUMENTS

Build a realistic schedule with deep-work blocks, breaks, and buffer. Batch similar tasks. Protect the most important work in my peak hours.
