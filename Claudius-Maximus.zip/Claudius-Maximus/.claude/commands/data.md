---
description: Back it up with stats
argument-hint: "[topic or claim]"
---

Respond to this with data and stats: $ARGUMENTS
Include relevant numbers, figures, and evidence, with sources where possible. Flag any stat you're not fully confident about.
