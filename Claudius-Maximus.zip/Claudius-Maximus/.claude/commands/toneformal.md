---
description: Rewrite in a formal tone
argument-hint: "[text]"
---

Rewrite this in a formal, professional tone: $ARGUMENTS
Keep the meaning. Precise and polished, no slang, no contractions, but still readable, not stiff.
