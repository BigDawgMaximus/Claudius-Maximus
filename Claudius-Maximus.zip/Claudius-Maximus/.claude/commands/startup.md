---
description: Pressure-test a startup idea
argument-hint: "[idea]"
---

Pressure-test this startup idea: $ARGUMENTS

Cover the problem, who has it badly, why now, the rough business model, and the top 3 risks. End with the single riskiest assumption I should test first.
