---
description: Set up a tracking system
argument-hint: "[metric/goal]"
---

Set up a simple tracking system for: $ARGUMENTS

Pick the one or two metrics that matter, how to log them with low friction, and a weekly review cadence. Don't over-engineer it.
