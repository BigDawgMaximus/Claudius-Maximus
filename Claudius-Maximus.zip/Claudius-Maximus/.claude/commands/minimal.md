---
description: Shortest possible response
argument-hint: "[task]"
---

Answer this in the fewest words possible: $ARGUMENTS
The absolute minimum that fully answers it. No padding.
