---
description: Reframe a point as a story
argument-hint: "[point or lesson]"
---

Turn this into a short, vivid story I can tell: $ARGUMENTS

Use a clear arc (setup, tension, turn, lesson). Keep it tight and specific with real detail. End on the takeaway without spelling it out too hard.
