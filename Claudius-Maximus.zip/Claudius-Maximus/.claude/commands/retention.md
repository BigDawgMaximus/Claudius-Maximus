---
description: Improve retention
argument-hint: "[product]"
---

Give me retention ideas for: $ARGUMENTS

Cover onboarding, the aha moment, habit loops, and win-back. Identify why people likely churn and the 3 changes most likely to keep them.
