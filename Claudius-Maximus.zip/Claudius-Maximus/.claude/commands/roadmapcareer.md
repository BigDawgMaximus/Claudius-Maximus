---
description: Build a career roadmap
argument-hint: "[goal + current state]"
---

Build a career roadmap for: $ARGUMENTS

Lay out 6, 12, and 24-month milestones with the skills, proof, and moves needed at each. Name the single most important next step.
