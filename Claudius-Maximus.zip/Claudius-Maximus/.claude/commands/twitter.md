---
description: Turn an idea into a short, punchy thread
argument-hint: "[topic]"
---

Write a short X/Twitter thread about: $ARGUMENTS

- Tweet 1 is the hook and must work as a standalone post.
- 5 to 8 tweets, each under 280 characters, one idea per tweet.
- Concrete, specific, no filler. End with a takeaway or soft CTA.
