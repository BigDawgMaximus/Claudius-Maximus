---
description: Run a weekly review
argument-hint: "[notes/week]"
---

Run a weekly review on: $ARGUMENTS

What went well, what didn't, what I learned, and the 3 priorities for next week. Ask me anything you need. Keep it short and honest.
