---
description: Tell me which skills to learn
argument-hint: "[goal or role]"
---

Tell me which skills to learn for: $ARGUMENTS

Separate must-have from nice-to-have, order them by leverage, and give the fastest credible way to learn and prove each one.
