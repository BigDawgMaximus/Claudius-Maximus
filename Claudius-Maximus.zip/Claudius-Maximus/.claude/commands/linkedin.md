---
description: Write a scroll-stopping LinkedIn post
argument-hint: "[topic]"
---

Write a LinkedIn post about: $ARGUMENTS

- Open with a line that stops the scroll. No "I'm excited to share".
- Short lines, one idea each, lots of white space.
- Include a real example or story and one clear takeaway.
- End with a line or question that invites comments. No hashtags unless I ask.
