---
description: Give an actionable checklist
argument-hint: "[task/goal]"
---

Turn this into an actionable checklist: $ARGUMENTS
Short, checkable items in the order I should do them. Group into sections if needed.
