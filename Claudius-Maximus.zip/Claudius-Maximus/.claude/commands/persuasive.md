---
description: Rewrite to be more convincing
argument-hint: "[text]"
---

Rewrite this to be more persuasive: $ARGUMENTS
Lead with what they care about, add proof, handle the obvious objection, and end with a clear reason to act. No empty hype.
