---
description: Quiz me to test knowledge
argument-hint: "[topic]"
---

Quiz me on: $ARGUMENTS

Ask one question at a time, wait for my answer, tell me if I'm right and why, then continue. Mix recall and application. Start now.
