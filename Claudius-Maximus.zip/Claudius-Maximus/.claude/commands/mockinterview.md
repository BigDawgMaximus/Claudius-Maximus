---
description: Run a mock interview
argument-hint: "[role]"
---

Run a mock interview for: $ARGUMENTS

Ask me one question at a time, wait for my answer, then give tight feedback before the next. Start now with the first question.
