---
description: Define the ideal customer profile
argument-hint: "[product]"
---

Define the ICP for: $ARGUMENTS

Give firmographics/demographics, the trigger that makes them buy, their goals, their objections, and where to find them. End with a one-line ICP statement.
