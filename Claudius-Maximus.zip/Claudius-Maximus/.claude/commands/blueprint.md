---
description: Give an implementation plan
argument-hint: "[goal]"
---

Give me an implementation plan for: $ARGUMENTS
Phases, the work in each, dependencies, and what "done" looks like. Practical enough to start today.
