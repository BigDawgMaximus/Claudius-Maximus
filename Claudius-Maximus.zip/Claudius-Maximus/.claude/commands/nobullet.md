---
description: Answer in flowing paragraphs
argument-hint: "[topic]"
---

Answer this in flowing prose, no bullets and no lists: $ARGUMENTS
Connected paragraphs that read naturally, with the ideas linked by logic, not symbols.
