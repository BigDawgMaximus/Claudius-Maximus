---
description: Build a decision matrix
argument-hint: "[decision + options]"
---

Help me decide: $ARGUMENTS

Build a weighted decision matrix (options vs criteria with weights), score it, and show the result. Then sanity-check whether the math matches my gut and why.
