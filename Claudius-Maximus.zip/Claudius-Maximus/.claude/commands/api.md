---
description: Design an API structure
argument-hint: "[feature/resource]"
---

Design the API for: $ARGUMENTS

Give endpoints, methods, request/response shapes, status codes, and auth. Note versioning and error format. Keep it RESTful and consistent.
