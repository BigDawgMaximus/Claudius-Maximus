---
description: Build a DM strategy
argument-hint: "[goal]"
---

Build a DM strategy for: $ARGUMENTS

Give me when to start a conversation, openers that aren't pitchy, how to add value first, and how to transition to the ask. Include 3 opener templates.
