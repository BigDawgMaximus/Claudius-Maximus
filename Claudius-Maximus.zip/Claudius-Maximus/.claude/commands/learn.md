---
description: Explain a topic clearly
argument-hint: "[topic]"
---

Explain this clearly: $ARGUMENTS

Start with a one-line intuition, then build up with a simple analogy and a concrete example. Define jargon as you go. End with the one thing most people get wrong.
