---
description: Design a database schema
argument-hint: "[app/feature]"
---

Design the database schema for: $ARGUMENTS

Give tables, columns, types, keys, and relationships. Note indexes and the one normalization vs performance tradeoff that matters here.
