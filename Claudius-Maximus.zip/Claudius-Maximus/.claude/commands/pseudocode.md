---
description: Plan logic in pseudocode
argument-hint: "[problem]"
---

Write clear pseudocode for: $ARGUMENTS

Logic and steps only, no language syntax. Make the control flow and data handling obvious so it translates to any language.
