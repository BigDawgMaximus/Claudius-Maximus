---
description: Improve performance
argument-hint: "[code]"
---

Optimize this code for performance: $ARGUMENTS

Identify the real bottleneck first (don't micro-optimize the wrong thing). Give the optimized version, the complexity before/after, and any tradeoffs.
