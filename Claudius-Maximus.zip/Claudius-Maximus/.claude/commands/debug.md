---
description: Find and fix bugs
argument-hint: "[code or error]"
---

You are a senior engineer doing a focused bug hunt.

Code / error / context:
$ARGUMENTS

1. Identify the most likely bug and explain the root cause, not just the symptom.
2. Give the exact fix as a corrected snippet or diff.
3. Flag nearby edge cases or related bugs. Lead with the bug, then the fix.
