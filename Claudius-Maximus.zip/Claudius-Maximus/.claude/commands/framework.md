---
description: Give a structured framework
argument-hint: "[topic/problem]"
---

Give me a framework for: $ARGUMENTS
A named, memorable structure (steps or components) I can reuse. Explain each part briefly and when to use it.
