---
description: Design a funnel
argument-hint: "[product + traffic source]"
---

Design a funnel for: $ARGUMENTS

Map awareness to purchase: hook, lead magnet, nurture, offer, follow-up. Note the one metric to watch at each stage and the most likely drop-off point.
