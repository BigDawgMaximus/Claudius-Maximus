---
description: Give a timeline-based roadmap
argument-hint: "[goal]"
---

Build a timeline-based roadmap for: $ARGUMENTS
Phases over time with milestones and the goal of each phase. Mark the single most important milestone.
