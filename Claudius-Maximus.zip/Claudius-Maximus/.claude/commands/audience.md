---
description: Define the target audience
argument-hint: "[product or content]"
---

Define the target audience for: $ARGUMENTS

Give me their demographics, the problem they feel, what they already tried, their objections, and the exact words they'd use. End with a one-line audience statement.
