---
description: List common mistakes
argument-hint: "[topic or skill]"
---

List the common mistakes in: $ARGUMENTS

For each: what people do, why it's wrong, and what to do instead. Order by how often it happens. Focus on the ones that quietly cause the most damage.
