---
description: Plan a slide-by-slide carousel
argument-hint: "[topic]"
---

Design a carousel about: $ARGUMENTS

Give me slide-by-slide copy. Slide 1 is the hook, last slide is the CTA. One idea per slide, short lines, and a note on what visual goes on each.
