---
description: Make a daily plan
argument-hint: "[tasks/goals]"
---

Make a daily plan from: $ARGUMENTS

Prioritize ruthlessly, time-block the day, protect deep work, and flag what to drop if the day goes sideways. Keep it realistic, not aspirational.
