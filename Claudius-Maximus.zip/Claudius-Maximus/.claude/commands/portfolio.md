---
description: Suggest portfolio project ideas
argument-hint: "[field + level]"
---

Suggest portfolio projects for: $ARGUMENTS

Give 5 projects that prove real skill, ordered easy to impressive. For each: what to build, what it demonstrates, and the one detail that makes it stand out.
