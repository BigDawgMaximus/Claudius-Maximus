---
description: Expand each point in depth
argument-hint: "[list or outline]"
---

Take each point below and expand it in depth: $ARGUMENTS
For every point: explain it, give a reason or example, and note an implication. Keep the structure but add real substance.
