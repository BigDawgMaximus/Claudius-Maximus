---
description: Generate practice questions
argument-hint: "[topic + level]"
---

Give me practice questions for: $ARGUMENTS

10 questions, easy to hard. Don't show answers yet. Tell me to ask for solutions when I'm ready, then explain each with the reasoning.
