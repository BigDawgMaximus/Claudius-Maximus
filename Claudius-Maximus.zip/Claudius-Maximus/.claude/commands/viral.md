---
description: Rewrite for maximum shareability
argument-hint: "[draft or topic]"
---

Rewrite this to maximize shares and saves: $ARGUMENTS

Sharpen the hook, cut everything that isn't earning attention, add a clear emotional or useful payoff, and make the takeaway quotable. Explain the 2 biggest changes you made.
