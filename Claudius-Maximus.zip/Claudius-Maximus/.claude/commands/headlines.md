---
description: Generate 10 headline options
argument-hint: "[topic or article]"
---

Write 10 headline options for: $ARGUMENTS

Vary the angles (curiosity, benefit, number, how-to, contrarian). Keep each under 12 words. Mark the 3 you'd test first and say why.
