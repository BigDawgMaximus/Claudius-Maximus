---
description: Answer in 3 to 5 lines
argument-hint: "[task]"
---

Answer this in 3 to 5 lines max: $ARGUMENTS
Tight and complete. No intro, straight to the point.
