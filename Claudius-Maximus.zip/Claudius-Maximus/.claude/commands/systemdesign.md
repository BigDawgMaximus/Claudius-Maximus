---
description: Design the architecture
argument-hint: "[system + requirements]"
---

Design the architecture for: $ARGUMENTS

Cover components, data flow, storage, and key tradeoffs. Note how it handles scale and failure. Keep it to the decisions that matter, with a simple diagram in text.
