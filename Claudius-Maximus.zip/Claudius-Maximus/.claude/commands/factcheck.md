---
description: Fact-check claims
argument-hint: "[claim or text]"
---

Fact-check this: $ARGUMENTS

For each claim: true, false, misleading, or unverifiable, with the reasoning and a source if you have one. Separate what's solid from what's spin. Note your confidence.
