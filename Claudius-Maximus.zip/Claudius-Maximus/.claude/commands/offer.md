---
description: Design an irresistible offer
argument-hint: "[product]"
---

Design a strong offer for: $ARGUMENTS

Stack the core result, bonuses, risk reversal, and a reason to act now. Make the value obviously greater than the price. Give me the one-paragraph offer.
