---
description: Coach me through salary negotiation
argument-hint: "[offer + context]"
---

Coach me on negotiating: $ARGUMENTS

Give my likely range, anchoring strategy, exact scripts for the counter, how to handle "that's our max", and non-salary levers. Keep me confident and polite.
