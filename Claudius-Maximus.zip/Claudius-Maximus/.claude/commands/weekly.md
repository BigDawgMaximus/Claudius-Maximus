---
description: Make a weekly plan
argument-hint: "[goals]"
---

Build a weekly plan for: $ARGUMENTS

Pick the 3 outcomes that matter, map them across the week, and leave buffer. End with a Friday checkpoint to review what actually moved.
