---
description: Rewrite a bio
argument-hint: "[current bio or details]"
---

Rewrite this bio: $ARGUMENTS

Give me 3 versions: one short (1 line), one medium (3 lines), one long (paragraph). Specific, human, no clichés. Make it clear what I do and who it's for.
