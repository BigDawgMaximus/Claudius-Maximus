---
description: Do structured deep research
argument-hint: "[topic/question]"
---

Research this thoroughly: $ARGUMENTS

Give the key findings, the strongest evidence on each side, where experts disagree, and what's still uncertain. Flag anything you're not confident about. Cite sources if available.
