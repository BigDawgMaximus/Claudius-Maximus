---
description: Summarize a topic
argument-hint: "[topic or text]"
---

Summarize this: $ARGUMENTS

Give the core idea in one line, then the 5 to 7 key points, then one sentence on why it matters. No fluff.
