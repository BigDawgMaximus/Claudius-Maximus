---
description: Find the weaknesses
argument-hint: "[work or argument]"
---

Critique this honestly: $ARGUMENTS

Point out the weakest assumptions, logic gaps, and risks. Be direct, not nice for its own sake. Then give the highest-impact fix for each.
