---
description: Recommend the best resources
argument-hint: "[topic + level]"
---

Recommend the best resources to learn: $ARGUMENTS

Give a short ordered path (start here, then this). Mix formats. For each, say what it's good for and roughly how long it takes. Quality over quantity.
