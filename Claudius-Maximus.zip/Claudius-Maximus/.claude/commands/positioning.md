---
description: Sharpen brand positioning
argument-hint: "[brand or person]"
---

Sharpen the positioning for: $ARGUMENTS

Fill in: who it's for, the enemy/old way, the new way, and the one-sentence positioning statement. Make it specific enough that it excludes someone.
